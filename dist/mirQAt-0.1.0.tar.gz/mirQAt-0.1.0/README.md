# mirQAt - Medical Imaging Research QA Toolkit

The original method implemented here was developed by Riqiang Gao and other members of the MASI lab. This package consists of methods that were useful in my own QA-ing with some modifications and optimizations.
