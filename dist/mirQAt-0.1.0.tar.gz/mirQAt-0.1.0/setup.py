# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mirqat']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.0.4,<2.0.0', 'pydicom>=2.0.0,<3.0.0', 'typer[all]>=0.2.1,<0.3.0']

entry_points = \
{'console_scripts': ['mirQAt = mirqat.main:app']}

setup_kwargs = {
    'name': 'mirqat',
    'version': '0.1.0',
    'description': '',
    'long_description': '# mirQAt - Medical Imaging Research QA Toolkit\n\nThe original method implemented here was developed by Riqiang Gao and other members of the MASI lab. This package consists of methods that were useful in my own QA-ing with some modifications and optimizations.\n',
    'author': 'Mirza Khan',
    'author_email': 'mirzask@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
