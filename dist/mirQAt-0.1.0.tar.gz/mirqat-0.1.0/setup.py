# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mirqat']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.0.4,<2.0.0', 'pydicom>=2.0.0,<3.0.0', 'typer[all]>=0.2.1,<0.3.0']

entry_points = \
{'console_scripts': ['mirQAt = mirqat.main:app']}

setup_kwargs = {
    'name': 'mirqat',
    'version': '0.1.0',
    'description': '',
    'long_description': '# mirQAt - Medical Imaging Research QA Toolkit\n\nThe original method implemented here was developed by Riqiang Gao and other members of the MASI lab and is available [here](https://github.com/MASILab/QA_tool). I would encourage users to use that tool as it is much more comprehensive. This package contains only a subset of methods that I used for my own QA-ing tasks. This package contains only these tools, with some modifications (fewer dependencies, list comprehension when possible, `pathlib.Path` instead of `os`, etc.) to be more lean and to create a user-friendly command-line interface to help streamline my own QA-ing.\n\n# Image File Structure\n\nI had used the following file structure, but I tried to modify the code to be more file structure agnostic. Please let me know if you have any issues or submit a PR to improve upon the current implementation.\n\nFile structure used:\n\n```\n. (root)\n├── 123456789 (subject_ID)\n│\xa0\xa0 ├── 5555555 (accession_number)\n│\xa0\xa0 │\xa0\xa0 ├── 2 (instance)\n│\xa0\xa0 │\xa0\xa0 │\xa0\xa0 ├── 1234.dcm\n│\xa0\xa0 │\xa0\xa0 │\xa0\xa0 ├── 1235.dcm\n│\xa0\xa0 │\xa0\xa0 │\xa0\xa0 ├── 1236.dcm\n│\xa0\xa0 │\xa0\xa0 ├── 3 (another instance)\n```\n\n# Checks\n\n## Instance number check\n\n`dcm-instance`\n\n## Slice distance check\n\n`dcm-slicedistance`\n\n## Generate QA report and Check instance number\n\n`instancen-fold`\n\n## Filter sessions with few slices but that pass the instance number check\n\n`filter-few-slices`\n',
    'author': 'Mirza Khan',
    'author_email': 'mirzask@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
